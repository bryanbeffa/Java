import java.io.*;
import java.nio.file.*;

/**
 *
 *
 * @author Matan Davidi e Paolo Gübeli
 * @version 26.02.18
 *
 */
public class ScreenManager {
	
	/** Il campo imgPaths definisce i percorsi delle immagini da stampare.*/
	private String[] imgPaths;

	/** Il campo width definisce la larghezza delle immagini da stampare.*/
	private int width;

	/** Il campo height definisce l'altezza delle immagini da stampare.*/
	private int height;

	/**
	* Il metodo ScreenManager è un metodo costruttore della
	* classe ScreenManager usato per istanziare nuovi oggetti
	* di tipo ScreenManager.
	*
	* @param imgPaths I percorsi delle immagini da stampare.
	* @param w La larghezza delle immagini da stampare.
	* @param h L'altezza delle immagini da stampare.
	*
	*/
	public ScreenManager(String[] imgPaths, int w, int h) {

		this.imgPaths = imgPaths;
		width = w;
		height = h;

	}

	/**
	* Il metodo transition è un metodo usato per stampare
	* un effetto di transizione tra l'animazione e il formulario.
	*
	*/
	public static void transition(){
		try{
			String anm = "";
			for(int i = 0; i < 52; i++){
				for(int j = 0; j < 82; j++){
					anm = "";
					int num = (int)(Math.random() * 3);
					if(num != 2){
						anm += num;
					}else{
						anm += " ";
					}
					System.out.print(anm);
				}
				Thread.sleep(25);
				System.out.println();				
			}
			for(int i = 0; i < 26; i++){
				Thread.sleep(30);
				System.out.println();
			}
		}catch(InterruptedException ie){
		}
	}

	/**
		* Il metodo main è un metodo usato per controllare 
		* il corretto funzionamento di ogni aspetto
		* della classe ScreenManager.
		*
		* @param args Gli argomenti passati da linea di comando
		*
		*/
	public static void main(String[] args) {
		
		boolean exit = false;
		int imgIndex = 0;

		try {

			try {

				//Inserire un array contenenti le stringhe che rappresentano i percorsi alle immagini. 
				String[] imgPaths = {"righe.bmp", "ubisoft.bmp", "gopro.bmp", "peas.bmp", "google.bmp", "cpt.bmp"};

				ScreenManager sm = new ScreenManager(imgPaths, 64, 64);

				int counter = 0;
				sm.showSplash(imgIndex);
				System.out.println("Premi ENTER per partecipare al concorso.");


				do {

					Thread.sleep(500);
					counter++;

					if (counter % 10 == 0) {

						if (imgIndex < imgPaths.length - 1) {

							imgIndex++;
							sm.showSplash(imgIndex);
							System.out.println("Premi ENTER per partecipare al concorso.");


						} else {

							imgIndex = -1;

						}

					}
					
				} while (System.in.available() == 0);

				System.in.read();
				transition();


			} catch (InterruptedException ie) {

				System.out.println("Esecuzione interrotta dall'utente.");

			}

		} catch (IOException ioe) {

			System.out.println("Errore di I/O.");

		}


	}

	/**
	* Il metodo showSplash è un metodo che stampa un'immagine
	* dell'array imgPaths dell'istanza corrente di ScreenManager.
	*
	* @param imgIndex L'indice dell'immagine all'interno dell'array da stampare. 
	* 
	* @throws IOException Errore di I/O in caso di malfunzionamento della tastiera. 
	*
	*/
	public void showSplash(int imgIndex) throws IOException{


		Path file = Paths.get(imgPaths[imgIndex]);
		if(Files.exists(file)){

			byte[] bytes = Files.readAllBytes(file);
			int[] ints = new int[bytes.length];

			for(int i = 0; i < bytes.length; i++){

				ints[i] = bytes[i] & 0xFF;

			}

			BitmapModel bM = new BitmapModel(ints);
			String img = bM.asciiPrinter();
			System.out.println(img);

		}

	}

}