package unused;

import java.util.ArrayList;
import java.util.List;

/**
* La classe FormRecord riceve i record
* da FormField e li inserisce in un
* ArrayList.
* @author Paolo Weishaupt
* @author Tristan Cambrini
* @version 26.02.2018
*/
public class FormRecord{

	/**
	* ArrayList che contiene i
	* fields ricevuti da FormField.
	*/
	List<FormField> fields = new ArrayList<>();

	/**
	* Metodo che riceve i FormField
	* e li aggiunge all'ArrayList.
	* @param form FormField ricevuto.
	*/
	private void addField(FormField field){
		fields.add(field);	
	}

	/**
	* Metodo che ritorna l'ArrayList.
	* @param nome Stringa per fare il sort.
	*/
	public List<FormField> getFields(){
		return fields;
	}

	/**
	* Costruttore.
	*/
	public FormRecord(){
//		addField("Nome",new NameValidator(20));
//		addField("Cognome",new NameValidator(20));
//		addField("E-mail",new EmailValidator());
//		addField("Anno",new IntegerValidator(2000, 2010));
//		addField("NomeGenitore",new NameValidator(20));
//		addField("CognomeGenitore",new NameValidator(20));
//		addField("E-mailGenitore",new EmailValidator());
//		addField("Scuola",new NameValidator(20));
//		addField("Classe",new IntegerValidator(1, 6));
	}
}