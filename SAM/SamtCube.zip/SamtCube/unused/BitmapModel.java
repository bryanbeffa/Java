import java.nio.file.*;
import java.io.*;
/**
*
*
*
*
*/
public class BitmapModel{
		
		/**
		* Questo attributo contiene i Byte dell'immagine bitmap.
		*/
		private int[] data;
		
		/**
		* Questo è un costruttore di data.
		* @param data Valore da assegnare a data.
		*/
		public BitmapModel(int[] data){
				this.data = data; 
		}
		
		/**
		* Questo metodo prende un trancio dell'array e lo ritorna
		* @param offset Coordinata dove inizia il trancio da prendere.
		* @param length Definisce la lunghezza del trancio da prendere.
		* @return Ritorna il trancio desidereato.
		*/
		public long getLong(int offset, int length){
			long value = 0;
			for(int i = offset; i < offset + length; i++){
				value = value | data[i] << (8 * (i - offset));
			}
			return value;
		}
		
		/**
		* Questo metodo trasforma un numero nella firma.
		* @return Ritorna una stringa contenente la firma del file.
		*/
		public String getSignature(){
			String firma = "";
			firma += (char)(data[0]);
			firma += (char)(data[1]);
			return firma;
		}
		
		/**
		* Questo metodo calcola la grandezza del file.
		* @return Ritorna un long contenente la grandezza del file.
		*/
		public long getFileSize(){
			long value = getLong(2,4);
			return value;
		}
		
		/**
		* Questo metodo calcola il primo riservato.
		* @return Ritorna un int contenente il primo riservato.
		*/
		public int getReserved1(){
			long value = getLong(6,2);
			return (int)value;
		}
		
		/**
		* Questo metodo calcola il seconda riservato.
		* @return Ritorna un int contenente il secondo riservato.
		*/
		public int getReserved2(){
			long value = getLong(8,2);
			return (int)value;
		}
		
		/**
		* Questo metodo calcola l'offset.
		* @return Ritorna un long contenente l'offset.
		*/
		public long getOffset(){
			long value = getLong(10,4);
			return value;
		}
		
		/**
		* Questo metodo calcola la grandezza del header.
		* @return Ritorna un long la grandezza del header.
		*/
		public long getDIBHeaderSize(){
			long value = getLong(14,4);
			return value;
		}
		
		/**
		* Questo metodo calcola la larghezza.
		* @return Ritorna un long contenente la larghezza.
		*/
		public long getWidth(){
			long value = getLong(18,4);
			return value;
		}
		
		/**
		* Questo metodo calcola la altezza.
		* @return Ritorna un long contenente la larghezza.
		*/
		public long getHeight(){
			long value = getLong(22,4);
			return value;
		}
		
		/**
		* Questo metodo calcola i bit per pixel.
		* @return Ritorna un int contenente i bit per pixel.
		*/
		public int getBitsPerPixel(){
			long value = getLong(28,2);
			return (int)value;
		}
		
		/**
		* Questo metodo calcola la compressione usata.
		* @return Ritorna una stringa con la compressione usata.
		*/
		public String getCompression(){
			long value = getLong(30,4);
			String[] compressioni = {
				"BI_RGB (none)",
				"BI_RLE8 (RLE 8-bit/pixel)",
				"BI_RLE4 (RLE 4-bit/pixel)",
				"BI_BITFIELDS (OS22XBITMAPHEADER: Huffman 1D)",
				"BI_JPEG (OS22XBITMAPHEADER: RLE-24)",
				"BI_PNG",
				"BI_ALPHABITFIELDS (RGBA bit field masks)",
				"BI_CMYK (none)",
				"BI_CMYKRLE8 (RLE-8)",
				"BI_CMYKRLE4 RLE-4",
			};
			return compressioni[(int)value];
		}
		
		/**
		* Questo metodo calcola la grandezza dell'immagine.
		* @return Ritorna un long contenente la grandezza dell'immagine.
		*/
		public long getImageSize(){
			long value = getLong(34,4);
			return value;
		}
		
		/**
		* Questo metodo calcola i pixel per metro.
		* @return Ritorna un long contenente i pixel per metro.
		*/
		public long getPixelPerMeterX(){
			long value = getLong(38,4);
			return value;
		}
		
		/**
		* Questo metodo calcola i pixel per metro.
		* @return Ritorna un long contenente i pixel per metro.
		*/
		public long getPixelPerMeterY(){
			long value = getLong(42,4);
			return value;
		}
		
		/**
		* Questo metodo calcola la grandezza di una riga.
		* @return Ritorna un long contenente la larghezza di una riga.
		*/
		public long getRowSize(){
			return  (getBitsPerPixel() * getWidth())/8;
		}
		
		/**
		* Questo metodo stampa i pixel in RGB.
		*/
		public void pixelsRGB(){
			int[] bytes = new int[(int)getRowSize()];
			for(int i = 1; i < getHeight(); i++){
				int position =(int)(getFileSize() - getRowSize() * i);
				for(int j = position; j < position + getRowSize(); j++){
					System.out.printf("%02x", data[j]);
					System.out.print(",");
					if((j % (int)(getBitsPerPixel()/8) - 2) == 0 && j != 0){
						System.out.print("\t");
					}
				}
				System.out.println();
			}
		}
		
		/**
		* Questo metodo stampa i pixel in una scala di grigi
		*/
		public void pixelsBW(){
			int[] bytes = new int[(int)getRowSize()];
			for(int i = 1; i < getHeight(); i++){
				int position =(int)(getFileSize() - getRowSize() * i);
				int l = 0;
				for(int j = position; j < position + getRowSize(); j++){
					bytes[l] = data[j];
					l++;
				}
				for(int j = 0; j < bytes.length; j += 3){
					int somma = 0;
					for(int k = 0; k < getBitsPerPixel()/8; k++){
						somma += bytes[j + k] + 1;
					}
					System.out.printf("%02x", (somma/(getBitsPerPixel()/8))/16);
					System.out.print("\t");
				}
				System.out.println();
			}
		}
		
		/**
		* Questo metodo stampa l'immagine in caratteri ascii.
		*
		* @return Una stringa contenente la rappresentazione ASCII dell'immagine contenuta nell'array$
		* data dell'istanza corrente di BitmapModel.
		*/
		public String asciiPrinter(){
			String re = "";
			char[] caratteri = {' ','.','*',':','o','&','8','#','@'};
			int bits = getBitsPerPixel()/8;
			int[] bytes = new int[(int)getRowSize()];
			for(int i = 1; i < getHeight(); i += 2){
				int position =(int)(getFileSize() - getRowSize() * i);
				int l = 0;
				for(int j = position; j < position + getRowSize(); j++){
					bytes[l] = data[j];
					l++;
				}
				for (int m = 0; m < (82 - getWidth()) / 2; m++) {			
					
					re += " ";

				}
				for(int j = 0; j < bytes.length; j += 3){
					int somma = 0;
					for(int k = 0; k < bits; k++){
						somma += bytes[j + k];
					}
					re += caratteri[(somma/bits)/32];
				}
				re += "\n";
			}

			return re;

		}
		
		/**
		* Metodo main usato per controllare 
		* il corretto funzionamento di ogni aspetto
		* della classe BitmapModel.
		*
		* @param args Gli argomenti passati da linea di comando
		*
		*/
		public static void main(String[] args){
			if(args.length > 0){
				Path file = Paths.get(args[0]);
				if(Files.exists(file)){
					try{
						byte[] bytes = Files.readAllBytes(file);
						int[] ints = new int[bytes.length];
						for(int i = 0; i < bytes.length; i++){
							ints[i] = bytes[i] & 0xFF;
						}
						BitmapModel bM = new BitmapModel(ints);
						
						System.out.println("Signature: " + bM.getSignature());
						System.out.println("File Size: " + bM.getFileSize() + " Byte");
						System.out.println("Reserved1: " + bM.getReserved1());
						System.out.println("Reserved2: " + bM.getReserved2());
						System.out.println("Offset: " + bM.getOffset());
						System.out.println("DIB Header Size: " + bM.getDIBHeaderSize());
						System.out.println("Image Width: " + bM.getWidth());
						System.out.println("Image Height: " + bM.getHeight());
						System.out.println("Bits per pixel: " + bM.getBitsPerPixel());
						System.out.println("Compression: " + bM.getCompression());
						System.out.println("Image Size: " + bM.getImageSize());
						System.out.println("X Pixels Per Meter: " + bM.getPixelPerMeterX());
						System.out.println("Y Pixels Per Meter: " + bM.getPixelPerMeterY());
						System.out.println("Row Size: " + bM.getRowSize());
						if(args.length > 1){
							if(args[1].equalsIgnoreCase("i")){ 
								System.out.println(bM.asciiPrinter());
							}else if(args[1].equalsIgnoreCase("b")){
								bM.pixelsRGB();
							}else{
								System.out.println("Comando non trovato");
							}
							if(args.length > 2){
								if(args[2].equalsIgnoreCase("i")){ 
									bM.pixelsBW();
								}else if(args[2].equalsIgnoreCase("b")){
									bM.pixelsRGB();
								}else{
									System.out.println("Comando non trovato");
								}
							}
						}
					}catch(IOException ioe){
						System.out.println("Errore");
					}
				}else{
					System.out.println("Impossibile trovare il file");
				}
			}else{
				System.out.println("Inserisci il file da leggere.");
			}
		}
}
