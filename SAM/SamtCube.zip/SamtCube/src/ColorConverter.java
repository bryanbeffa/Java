/*
 * The MIT License
 *
 * Copyright 2018 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

/**
 * http://web.archive.org/web/20131004221555/http://en.wikipedia.org/wiki/ANSI_escape_code#Colors 
*
 * @author andreaalbertini
 */
public class ColorConverter {

    static int[][] colors16 = {
        {0, 0, 0}, //black
        {170, 0, 0}, //red
        {0, 170, 0}, //green
        {170, 85, 0}, //brown/yellow
        {0, 0, 170}, //blue
        {170, 0, 170}, //magenta
        {0, 170, 170}, //cyan
        {170, 170, 170},//gray
        {85, 85, 85}, //dark gray
        {255, 85, 85}, //b/l red
        {85, 255, 85}, //b/l green
        {255, 255, 85}, //b/l yellow
        {85, 85, 255}, //b/l blue
        {255, 85, 255}, //b/l magenta
        {85, 255, 255}, //b/l cyan
        {255, 255, 255} //white 
    };

    public static int getNearestAnsi16(int[] pixelData) {
        int nearest = 0;
        for (int i = 1; i < colors16.length; i++) {
            int diff = getDistance(i, pixelData);
            if (getDistance(nearest, pixelData) > getDistance(i, pixelData)) {
                nearest = i;
            }
        }
        return nearest;
    }

    private static int getDistance(int color16Id, int[] pixelData) {
        return Math.abs(colors16[color16Id][0] - pixelData[2])
                + Math.abs(colors16[color16Id][1] - pixelData[1])
                + Math.abs(colors16[color16Id][2] - pixelData[0]);
    }
}
