

/*
 * The MIT License
 *
 * Copyright 2018 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

/**
 * Classe utile per valutare la validità di una valore di tipo String.
 *
 * @author andreaalbertini
 */
public class Validator {

    /**
     * Il messaggio di errore più recente
     */
    protected String errorMessage = "";

    /**
     * Valuta il valore di value, se il valore è valido ritorna true. Se il
     * valore non è valido ritorna false e memorizza il messaggio di errore che
     * potrà essere letto tramite il metodo getErrorMessage().
     *
     * Sono considerate valide le stringhe non null e non vuote.
     *
     * @param value il valore da valutare
     * @return true se value è valido, false altrimenti
     */
    public boolean isValid(String value) {
        errorMessage = "";
        if (value != null && value.trim().length() != 0) {
            return true;
        } else {
            errorMessage = "Stringa troppo corta " + value;
            return false;
        }
    }

    /**
     * Restituisce il messaggio di errore prodotto dall'ultima invocazione di
     * isValid(). Se la valutazione precedente non ha prodotto errori ritorna
     * una stringa vuota.
     *
     * @return il messaggio di errore se ve ne è uno, stringa vuota altrimenti
     */
    public String getErrorMessage() {
        return errorMessage;
    }
}
