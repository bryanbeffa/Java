/*
 * The MIT License
 *
 * Copyright 2018 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */


/**
 * Implementa la validazione di un nome.
 *
 * @author andreaalbertini
 */
public class NameValidator extends Validator {

    private int maxLength;

    public NameValidator(int maxLength) {
        this.maxLength = maxLength;
    }

    /**
     * Valuta il valore di value, se il valore è valido ritorna true. Se il
     * valore non è valido ritorna false e memorizza il messaggio di errore che
     * potrà essere letto tramite il metodo getErrorMessage().
     *
     * Sono considerate valide le stringhe non null e non vuote che rispettano
     * le regole seguenti:
     * <ul>
     * <li>contiene solo caratteri alfabetici (anche accentati), spazio o
     * apostrofo</li>
     * <li>rispetta la lunghezza massima definita da maxLength</li>
     * </ul>
     *
     * @param value il valore da valutare
     * @return true se value è valido, false altrimenti
     */
    @Override
    public boolean isValid(String value) {
        if (value == null) {
            errorMessage = "stringa nulla non ammessa";
            return false;
        } else {
            String input = value.trim();
            if (input.length() == 0) {
                errorMessage = "stringa vuota non ammessa";
                return false;
            } else if (input.length() > maxLength) {
                errorMessage = "valore troppo lungo, inserire al massimo " + maxLength + " caratteri";
                return false;
            }
            for (int i = 0; i < value.length(); i++) {
                Character c = new Character(value.charAt(i));
                if (!(Character.isAlphabetic(c) || c == ' ' || c == '\'')) {
                    errorMessage = "carattere non ammesso \'" + c + "\'";
                    return false;
                }
            }
            return true;
        }
    }

}
