

/*
 * The MIT License
 *
 * Copyright 2018 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/**
 * Classe utile per validare un valore numerico intero.
 *
 * @author andreaalbertini
 */
public class IntegerValidator extends Validator {

    private int minValue;
    private int maxValue;

    public IntegerValidator(int minValue, int maxValue) {
        this.minValue = minValue;
        this.maxValue = maxValue;
    }

    /**
     * Valuta il valore di value, se il valore è valido ritorna true. Se il
     * valore non è valido ritorna false e memorizza il messaggio di errore che
     * potrà essere letto tramite il metodo getErrorMessage().
     *
     * Sono considerate valide le stringhe che rappresentano un numero intero
     * compreso nel range definito da [minValue;maxValue].
     *
     * @param value il valore da valutare
     * @return true se value è valido, false altrimenti
     */
    @Override

    public boolean isValid(String value) {
        if (value == null) {
            errorMessage = "stringa nulla non ammessa";
            return false;
        } else if (value.length() == 0) {
            errorMessage = "stringa vuota non ammessa";
            return false;
        } else {
            try {
                int n = Integer.parseInt(value);
                if (n < minValue) {
                    this.errorMessage = "valore troppo piccolo " + value;
                    return false;
                } else if (n > maxValue) {
                    this.errorMessage = "valore troppo grande " + value;
                    return false;
                } else {
                    return true;
                }
            } catch (NumberFormatException nfe) {
                this.errorMessage = "valore non valido " + value;
                return false;
            }
        }
    }

    public static void main(String[] args) {
//        IntegerValidator iv = new IntegerValidator(1, 6);
//        for (int i = -1; i < 8; i++) {
//            System.out.printf("%d ", i);
//            if (iv.isValid(i + "")) {
//                System.out.println("OK");
//            } else {
//                System.out.println(iv.getErrorMessage());
//            }
//        }
//        System.out.printf("%s ", "Stringa vuota");
//        if (iv.isValid("")) {
//            System.out.println("OK");
//        } else {
//            System.out.println(iv.getErrorMessage());
//        }
//
//        System.out.printf("%s ", null);
//        if (iv.isValid(null)) {
//            System.out.println("OK");
//        } else {
//            System.out.println(iv.getErrorMessage());
//        }
    }
}
