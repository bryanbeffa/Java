
/**
 *Questo programma si occupa di prendere le risposta sbagliate, la risposta giusta di metterle in un unico array dove l'ordie verrà cambiato sempre,
 *si memorizza anche la posizione della domanda corretta per poterla prendere anche dopo averle mischiate,
 *prende la domanda e la memorizza.
 *
 * @author Mattia Ruberto
 * @author Thor Düblin
 * @date 27.02.2018
 */
public class QuizQuestion {

    /**
     * Array di stringhe, sone le risposte che l'utente potrà scegliere
     */
    private String[] answers;

    /**
     * Intero, è la posizione della risposta corretta nell'array answers
     */
    private int correctAnswer;

    /**
     * String, definisce la stringa contenente la domanda
     */
    private String questionText;

    /**
     * Metodo che ritorna il testo della domanda
     *
     * @return testo della domanda
     */
    public String getQuestionText() {
        return this.questionText;
    }

    /**
     * Metodo che ritorna la posizione nell'array della risposta esatta
     *
     * @return la posizione della risposta esatta nell'array
     */
    public int getCorrectAnswer() {
        return this.correctAnswer;
    }

    /**
     * Metodo che ritorna l'array con dentro tutte le risposte possibili
     *
     * @return l'array con tutte le risposte possibili a suo interno
     */
    public String[] getAnswers() {
        return this.answers;
    }

    /**
     * Costruttore contenete il testo delle domande, le risposte corrette e
     * quelle sbagliate Il costruttore setta answers mettendogli dentro le
     * risposte corrette e quelle sbagliate e poi le mischia casualmente ogni
     * volta
     *
     * @param questionText testo della domanda
     * @param correctAnswer stringa contenente la risposta corretta
     * @param wrongAnswers array di stringhe contenente le risposte errate
     */
    public QuizQuestion(String questionText, String correctAnswer, String[] wrongAnswers) {
        this.questionText = questionText;
        answers = new String[(wrongAnswers.length + 1)];

        answers[0] = correctAnswer.trim(); //metto la risposta corretta al primo posto momentaneamente
        this.correctAnswer = 0; // memorizzo l'indice che deve essere fissato all'inizio

        for (int i = 1; i < answers.length; i++) {
            answers[i] = wrongAnswers[i - 1].trim();
        }

        this.answers = orderingRandom(this.answers);
    }

    /**
     * Questo è il metodo che si occupa di prendere l'array answers e di
     * mischiare ogni volta casualmente le domande al suo interno
     *
     * @param answer, array con dentro tutte le risposte possibili
     * @return ritorno l'array con l'ordine delle domande mischiato
     */
    public String[] orderingRandom(String[] answer) {
        int numTimesMixUp = (int) ((100 - 0 + 1) * Math.random() + 0); //numero di volte che le domande verranno girate fra loro
        String k = ""; // variabile che serve come mezzo di comunicazione per girare le due domande
        int counterPositionArray = 0; // variabile che viene utilizza come posizione nell'array dato che non si può utilizzare i perchè sorpasserebbe la grandezza dell'array
        for (int i = 0; i < numTimesMixUp; i++) {
            counterPositionArray++;
            if (counterPositionArray == answer.length - 1) { // azzero il contatore se sorpassa la grandezza dell'array
                counterPositionArray = 0;
            }

            k = answer[counterPositionArray + 1];  //scambio le domande tra loro
            answer[counterPositionArray + 1] = answer[counterPositionArray];
            answer[counterPositionArray] = k;

            if (this.correctAnswer == counterPositionArray) { // setto l'indice della risposta corretta per ricordarsi dove è stata messa
                this.correctAnswer = counterPositionArray + 1;
            } else if (this.correctAnswer == counterPositionArray + 1) {
                this.correctAnswer = counterPositionArray;
            }
        }
        return answer;
    }

    public static void main(String args[]) {
        String questionText = "Quanti anni ha lui?";
        String[] wrongAnswer = {"Ha 4 anni", "Ha 11 anni", "Ha 20 anni", "Ha 60 anni", "Ha 35 anni"};
        String correctAnswer = "Ha 55 anni";
        QuizQuestion domande = new QuizQuestion(questionText, correctAnswer, wrongAnswer);
        System.out.println(domande.questionText);
        String risposte[] = domande.getAnswers();
        for (int i = 0; i < risposte.length; i++) {
            System.out.println(risposte[i]);
        }
        System.out.println("Indice risposta giusta: " + domande.getCorrectAnswer());
    }
}
