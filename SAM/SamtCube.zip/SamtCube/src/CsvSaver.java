
import java.io.*;
import java.util.*;
import java.nio.file.*;
import static java.nio.file.StandardOpenOption.APPEND;

/**
 * Questro programma prepara una stringa con i dati di un utente e la mette in
 * un file csv.
 *
 * @author JariNaeser GabrieleAlessi
 * @version 26.2.2018
 */
public class CsvSaver {

    private String hostname;
    /**
     * Attributo csvFilePath.
     */
    private Path csvPath;

    /**
     * Attributo separator.
     */
    private char separator;

    /**
     * Costruttore CsvSaver....
     *
     * @param csvFilePath Percorso in cui viene salvato il file.
     * @param separator Carattere che separa le risposte nel csv.
     * @throws Previene eventuali eccezioni create nel programma.
     */
    public CsvSaver(String hostname, String csvFilePath, String csvFileName, char separator) throws IOException {
        Calendar cal = Calendar.getInstance();
        String fileName = String.format("%s-%s-%s-%s",
                cal.get(Calendar.DAY_OF_MONTH),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.YEAR),
                csvFileName
        );
        this.hostname = hostname;
        this.csvPath = Paths.get(csvFilePath).resolve(fileName);
        this.separator = separator;
        Files.createDirectories(this.csvPath.toAbsolutePath().getParent());
        if (!Files.exists(this.csvPath)) {
            Files.createFile(csvPath);
            System.out.println("Created new file " + csvPath.toAbsolutePath().toString());
        }
    }

    /**
     * Il metodo toCsvFormat prepara una stringa nel formato corretto per il
     * csv. Esempio: fabio,rossi,fabio.rossi@bluewin.ch
     *
     * @param field Lista di FormField contenente tutti i dati degli utenti.
     * @return Ritorna una stringa contenente tutti i dati di una persona
     * formattata nel modo corretto.
     */
    private String toCsvLine(FormRecord record) {
        String text = System.currentTimeMillis() + "," + hostname + ",";
        for (Map.Entry<String, FormField> entry : record.getFields().entrySet()) {
            text += entry.getValue().getValue() + separator;
        }
        return text + System.lineSeparator();
    }

    private String toCsvHeader(FormRecord record) {
        String text = "Time,hostname,";
        for (Map.Entry<String, FormField> entry : record.getFields().entrySet()) {
            text += entry.getKey() + separator;
        }
        return text + System.lineSeparator();
    }

    /**
     * Metodo save.
     *
     * @param record Oggetto record contenente la lista con tutte le risposte.
     * @throws Previene eventuali eccezioni create nel programma.
     */
    public void save(FormRecord record) throws IOException {
        if (Files.size(csvPath) == 0) {
            Files.write(csvPath, toCsvHeader(record).getBytes());
        }
        Files.write(csvPath, toCsvLine(record).getBytes(), APPEND);
    }

}
