
/**
 * La classe FormField salva il come del campo e il suo valore inserito dal utente
 *
 * @author Fadil Smajilbasic
 * @version 26.02.2018
 */
public class FormField {

    /**
     * La variabile contenente il valore passato come parametro dal costruttore.
     */
    private String value;

    /**
     * La variabile contenente il nome del campo.
     */
    private String name;

    private String explaination = "";
    /**
     * La variabile contenente il tipo di validator che verrà utilizzato per il
     * controllo.
     */
    private Validator validator;

    /**
     * Metodo getter per la variabile validator.
     *
     * @return il validator.
     */
    public Validator getValidator() {
        return validator;
    }

    /**
     * Metodo getter per la variabile value.
     *
     * @return il valore di value.
     */
    public String getValue() {
        return value;
    }

    /**
     * Metodo setter per la variabile value.
     *
     * @param value il valore da settare.
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Metodo getter per la variabile name.
     *
     * @return il nome del campo.
     */
    public String getName() {
        return name;
    }

    /**
     * Metodo setter per la variabile name
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    public String getExplaination() {
        return explaination;
    }

    /**
     * Costruttore per la classe FormField.
     *
     * @param nome il nome del campo da settere nella varaibile nome.
     * @param validator il valdiatore.
     */
    public FormField(String nome, Validator validator) {
        setName(nome);
        this.validator = validator;
    }

    public FormField(String nome, Validator validator, String explaination) {
        this(nome, validator);
        this.explaination = explaination;
    }

}
