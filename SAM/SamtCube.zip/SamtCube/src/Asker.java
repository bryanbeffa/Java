
import java.io.*;

/**
 * Asker Classe che permette di fare le domande agli utenti.
 *
 * @author Filippo Finke
 * @author Luca Di Bello
 * @author Carlo Pezzotti
 *
 * @version 26.02.18
 */
public class Asker {

    /**
     * Tempo massimo per rispondere a una domanda, dopo TIMEOUT ms di inattività
     * il formulario riparte.
     */
    private static final int TIMEOUT = 90000;
    /**
     * Valore di default per quitCommand.
     */
    public static final String DEFAULT_QUIT_CMD = "quit";
    /**
     * Attributo che rappresenta il comando per far sollevare un eccezione.
     */
    private String quitCommand;

    /**
     * Costruttore con 1 parametro
     *
     * @param quitCommand Il comando per il quale deve sollevare un eccezione.
     */
    public Asker(String quitCommand) {
        if (quitCommand != null && quitCommand.trim().length() != 0) {
            this.quitCommand = quitCommand.trim();
        } else {
            this.quitCommand = DEFAULT_QUIT_CMD;
        }
    }

    /**
     * Metodo che permette di fare una domanda e validarne i valori.
     *
     * @param message La domanda da porre all'utente.
     * @param validator Il validator per convalidare il dato.
     * @return Il valore validato inserito dall'utente.
     * @throws FormInterruptedException Quanto l'utente desidera chiudere il
     * formulario.
     * @throws IOException Quando vi è un problema di lettura della tastiera.
     */
    public String ask(String message, Validator validator) throws FormInterruptedException, IOException {
        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader tastiera = new BufferedReader(input);
        String value = "";
        while (true) {
            System.out.printf("%s: ", message, quitCommand);
            long time = System.currentTimeMillis();
            int read = 0;
            do {
                if (System.in.available() != 0) {
                    read = System.in.read();
                    if (read != '\n') {
                        value += (char) read;
                        time = System.currentTimeMillis();
                    }
                } else {
                    try {
                        Thread.sleep(500);
                        if (System.currentTimeMillis() - time > TIMEOUT) {
                            throw new FormInterruptedException("Tempo scaduto");

                        }
                    } catch (InterruptedException ex) {

                    }
                }
            } while (read != '\n');
            value = value.trim();
            if (value.equalsIgnoreCase(quitCommand)) {
                throw new FormInterruptedException("Compilazione interrotta");
            } else if (validator.isValid(value)) {
                return value;
            } else {
                System.out.println("Errore: " + validator.getErrorMessage());
                value = "";
            }
        }
    }

}
