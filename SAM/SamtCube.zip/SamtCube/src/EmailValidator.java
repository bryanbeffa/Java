/*
 * The MIT License
 *
 * Copyright 2018 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

/**
 * Classe utile per verificare la validità di un indirizzo email.
 *
 * @author andreaalbertini
 */
public class EmailValidator extends Validator {

    /**
     * Se ve ne è una, ritorna la local-part dell'indirizzo specificato da
     * emailAddress, altrimenti ritorna una stringa vuota.
     *
     * @param emailAddress l'indirizzo da cui prelevare la local-part
     * @return la local part se presente, stringa vuota altrimenti
     */
    private String getLocalPart(String emailAddress) {
        if (emailAddress.indexOf('@') != -1) {
            return emailAddress.substring(0, emailAddress.indexOf('@'));
        } else {
            return "";
        }
    }

    /**
     * Se ve ne è uno, ritorna la parte dominio dell'inidirizzo specificato da
     * emailAddres, altrimenti ritorna stringa vuota.
     *
     * @param emailAddress l'indirizzo da cui prelevare il nome dominio
     * @return il dominiose presente, stringa vuota altrimenti
     */
    private String getDomainPart(String emailAddress) {
        if (emailAddress.indexOf('@') != -1) {
            return emailAddress.substring(emailAddress.indexOf('@') + 1);
        } else {
            return "";
        }
    }

    /**
     * Valuta il valore di value, se il valore è un indirizzo email valido
     * ritorna true. Se il valore non è valido ritorna false e memorizza il
     * messaggio di errore che potrà essere letto tramite il metodo
     * getErrorMessage().
     *
     * Sono considerate valide le stringhe che rappresentano un indirizzo email
     * valido. Un email valido deve essere composto nel modo seguente
     * <pre>
     * local-part@domain
     * </pre>
     *
     * local-part non può essere vuota e può contenere:
     * <ul>
     * <li>caratteri alfabetici ASCII maiuscoli [A-Z] e minuscoli [a-z]</li>
     * <li>i caratteri numerici ASCII [0-9]</li>
     * <li>i caratteri speciali '-' (meno) o '_' underscore</li>
     * <li>il carattere punto '.' a patto che non sia il primo o l'ultimo
     * carattere, non sono ammesi 2 o più punti consecutivi</li>
     * <li>al massimo 64 caratteri</li>
     * </ul>
     *
     * domain (hostname) non può essere vuoto e deve avere una lunghezza massima
     * di 255 caratteri ed essere composto da una sequenza di nomi di dominio
     * (almeno 2, secondo e primo livello) separati da '.' (punto). Ogni nome di
     * dominio può contenere:
     * <ul>
     * <li>caratteri alfabetici ASCII maiuscoli [A-Z] e minuscoli [a-z]</li>
     * <li>i caratteri numerici ASCII [0-9], a patto che il dominio di primo
     * livello non sia composto esclusivamente da numeri</li>
     * <li>il carattere speciale '-' (meno) a patto che non sia il primo o
     * ultimo carattere</li>
     * <li>al massimo 63 caratteri</li>
     * </ul>
     *
     * @param value il valore da valutare
     * @return true se value è valido, false altrimenti
     */
    @Override
    public boolean isValid(String value) {
        return isLocalPartValid(getLocalPart(value))
                && isDomainValid(getDomainPart(value));
    }

    /**
     * Verifica la validità della local-part di un indirizzo. local-part non può
     * essere vuota e può contenere:
     * <ul>
     * <li>caratteri alfabetici ASCII maiuscoli [A-Z] e minuscoli [a-z]</li>
     * <li>i caratteri numerici ASCII [0-9]</li>
     * <li>i caratteri speciali '-' (meno) o '_' underscore</li>
     * <li>il carattere punto '.' a patto che non sia il primo o l'ultimo
     * carattere, non sono ammesi 2 o più punti consecutivi</li>
     * <li>al massimo 64 caratteri</li>
     * </ul>
     *
     * @param localPart il valore da valutare
     * @return true se la localPart è valida, false altrimenti
     */
    private boolean isLocalPartValid(String localPart) {
        errorMessage = "";
        if (localPart == null || localPart.length() == 0) {
            errorMessage = "local part nulla non ammessa";
            return false;
        } else if (localPart.length() > 64) {
            errorMessage = "local part troppo lunga";
            return false;
        } else if (localPart.startsWith("-")) {
            errorMessage = "il carattere \'-\' non è ammesso all'inizio dell'indirizzo";
            return false;
        } else if (localPart.endsWith("-")) {
            errorMessage = "il carattere \'-\' non è ammesso alla fine dell'indirizzo";
            return false;
        } else if (localPart.startsWith(".")) {
            errorMessage = "il carattere \'.\' non è ammesso all'inizio dell'indirizzo";
            return false;
        } else if (localPart.endsWith(".")) {
            errorMessage = "il carattere \'.\' non è ammesso alla fine dell'indirizzo email";
            return false;
        } else if (localPart.contains("..")) {
            errorMessage = "il carattere \'.\' non può essere ripetuto";
            return false;
        } else {
            for (int i = 0; i < localPart.length(); i++) {
                char c = localPart.charAt(i);
                if (!((c >= 'a' && c <= 'z')
                        || (c >= 'A' && c <= 'z')
                        || (c >= '0' && c <= '9')
                        || (c == '-' || c == '_' || c == '.'))) {
                    errorMessage = "carattere non ammesso \'" + c + "\' ";
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * Verifica la validità della parte domain di un indirizzo. domain
     * (hostname) non può essere vuoto e deve avere una lunghezza massima di 255
     * caratteri ed essere composto da una sequenza di nomi di dominio (almeno
     * 2, secondo e primo livello) separati da '.' (punto). Ogni nome di dominio
     * può contenere:
     * <ul>
     * <li>caratteri alfabetici ASCII maiuscoli [A-Z] e minuscoli [a-z]</li>
     * <li>i caratteri numerici ASCII [0-9], a patto che il dominio di primo
     * livello non sia composto esclusivamente da numeri</li>
     * <li>il carattere speciale '-' (meno) a patto che non sia il primo o
     * ultimo carattere</li>
     * <li>al massimo 63 caratteri</li>
     * </ul>
     *
     *
     * @param domainPart il valore da valutare
     * @return true se la localPart è valida, false altrimenti
     */
    private boolean isDomainValid(String domainPart) {
        errorMessage = "";
        if (domainPart.length() > 255) {
            errorMessage = "domain troppo lungo";
            return false;
        } else if (domainPart.length() == 0) {
            errorMessage = "domain nulla non ammessa";
            return false;
        } else {
            String[] domains = domainPart.split("\\.");
            if (domains.length < 2) {
                errorMessage = "domain di primo livello mancante " + domains.length;
                return false;
            } else {
                for (int i = 0; i < domains.length; i++) {
                    String domain = domains[i];
                    if (domain.length() == 0) {
                        errorMessage = "domain part nulla non ammessa";
                        return false;
                    } else if (domain.length() > 63) {
                        errorMessage = "domain part troppo lunga " + domain;
                        return false;
                    } else if (domain.startsWith("-")) {
                        errorMessage = "il carattere \'-\' non è ammesso all'inizio di una domain";
                        return false;
                    } else if (domain.endsWith("-")) {
                        errorMessage = "il carattere \'-\' non è ammesso alla fine ddi un domain";
                        return false;
                    } else {
                        for (int j = 0; j < domain.length(); j++) {
                            char c = domain.charAt(j);
                            if (!((c >= 'a' && c <= 'z')
                                    || (c >= 'A' && c <= 'z')
                                    || (c >= '0' && c <= '9')
                                    || (c == '-'))) {
                                errorMessage = "il carattere \'" + c + "\' non è ammesso";
                                return false;
                            }
                        }
                        if (i == domains.length - 1) {
                            if (domain.replaceAll("[0-9]", "").length() == 0) {
                                errorMessage = "il dominio di primo livello non può contenere solo numeri " + domain;
                                return false;
                            }

                        }
                    }
                }
                return true;
            }
        }
    }

    public static void main(String[] args) {
        String[] addr = {
            "andrea.alberrtini@gmail.com",
            "andrea.alberrtini@A",
            "@",
            "andrea@A.com",
            "èndrea@A.com",
            "and..rea@A.com",
            "andre!a@A.com",
            "andrea@albertini.0123",
            "andrea@192.168.1.1",
            "andrea@192.168.1.com",};
        EmailValidator emv = new EmailValidator();
        for (int i = 0; i < addr.length; i++) {
            String localPart = emv.getLocalPart(addr[i]);
            String domainPart = emv.getDomainPart(addr[i]);
            System.out.printf("%s ",
                    addr[i]
            //localPart,
            //domainPart
            );
            if (!emv.isLocalPartValid(localPart) || !emv.isDomainValid(domainPart)) {
                System.out.println(emv.getErrorMessage());
            } else {
                System.out.println("OK");
            }

        }
    }
}
