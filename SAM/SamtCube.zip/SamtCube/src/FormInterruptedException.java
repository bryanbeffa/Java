/**
* FormInterruptedException
* @author Filippo Finke
* @version 26.02.2018
*/
public class FormInterruptedException extends Exception {

	/**
	* Costruttore con 1 parametro.
	* @param message Il messaggio di errore.
	*/
	public FormInterruptedException(String message)
	{
		super(message);
	}
}