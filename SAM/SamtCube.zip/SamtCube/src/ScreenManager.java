
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 *
 * @author Matan Davidi e Paolo Gübeli
 * @version 26.02.18
 *
 */
public class ScreenManager {

    /**
     * Il campo imgPaths definisce i percorsi delle immagini da stampare.
     */
    private List<Path> imgPaths;
    private List<BitmapModel> images;

    /**
     * Il campo width definisce la larghezza delle immagini da stampare.
     */
    private int width;

    /**
     * Il campo height definisce l'altezza delle immagini da stampare.
     */
    private int height;
    public final int DEFAULT_WIDTH;
    public final int DEFAULT_HEIGHT;

    /**
     * Il metodo ScreenManager è un metodo costruttore della classe
     * ScreenManager usato per istanziare nuovi oggetti di tipo ScreenManager.
     *
     * @param imgPath la cartella in cui si trovano le immagini bmp
     * @param defaultWidth la larghezza di default del terminale
     * @param defaultHeight l'altezza di default del
     *
     */
    public ScreenManager(String imgPath, int defaultWidth, int defaultHeight)
            throws IOException {
        DirectoryStream<Path> imgDir = Files.newDirectoryStream(Paths.get("img"), "*.bmp");
        this.imgPaths = new ArrayList<>();
        this.images = new ArrayList<>();
        for (Path path : imgDir) {
            imgPaths.add(path);
            images.add(new BitmapModel(Files.readAllBytes(path)));
        }
        this.DEFAULT_WIDTH = defaultWidth;
        this.DEFAULT_HEIGHT = defaultHeight;
    }


    public void clearScreen() {
        System.out.print("\033[40m");
        System.out.print("\033[0;0H");
        System.out.print("\033[2J");
        System.out.flush();
    }
    public void home() {
        System.out.print("\033[0;0H");
        System.out.flush();
    }
    /**
     * Il metodo showSplash è un metodo che stampa un'immagine dell'array
     * imgPaths dell'istanza corrente di ScreenManager.
     *
     * @param imgIndex L'indice dell'immagine all'interno dell'array da
     * stampare.
     *
     * @throws IOException Errore di I/O in caso di malfunzionamento della
     * tastiera.
     *
     */
    public void showSplash() throws IOException {
        int imgId = 0;
        do {
            home();
            printImage(imgId % imgPaths.size());
            //printCentered("Premere [Enter] per iniziare");
            int cnt = 0;
            do {
                try {
                    Thread.sleep(250);
                } catch (InterruptedException ex) {
                    return;
                }
                cnt++;
            } while (cnt < 20 && System.in.available() == 0);
            imgId++;
        } while (System.in.available() == 0);

        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader tastiera = new BufferedReader(input);

        tastiera.readLine();
    }

    public void printCentered(String text) {
        for (int i = 0; i < (width - text.length()) / 2; i++) {
            System.out.print(" ");
        }
        System.out.print(text);
    }

    public void printlnCentered(String text) {
        printCentered(text + "\n");
    }

    public void setBigFont() {
        setFont("Uni3-Terminus24x12");
        this.width = getTermWidth();
        this.height = getTermHeight();
    }

    public void setSmallFont() {
        setFont("Uni3-Terminus12x6");
        this.width = getTermWidth();
        this.height = getTermHeight();
    }

    public void setGraphicFont() {
        setFont("/home/pi/pix2.psf");//"Uni3-Terminus12x6");
        this.width = getTermWidth();
        this.height = getTermHeight();
    }

    public void setFont(String font) {
        try {
            Process p = Runtime.getRuntime().exec("setfont " + font);
            p.waitFor();
        } catch (IOException ex) {
        } catch (InterruptedException ex) {
            return;
        }
    }

    private int getTermWidth() {
        try {
            List<String> lines = execTermCommand("tput cols");
            if (lines.size() > 0) {
                return Integer.parseInt(lines.get(0));
            } else {
                return DEFAULT_WIDTH;
            }
        } catch (IOException
                | InterruptedException
                | InputMismatchException ex) {
            return DEFAULT_WIDTH;
        }
    }

    private int getTermHeight() {
        try {
            List<String> lines = execTermCommand("tput lines");
            if (lines.size() > 0) {
                return Integer.parseInt(lines.get(0));
            } else {
                return DEFAULT_HEIGHT;
            }
        } catch (IOException
                | InterruptedException
                | InputMismatchException ex) {
            return DEFAULT_HEIGHT;
        }
    }

    public List<String> execTermCommand(String cmd)
            throws IOException, InterruptedException {
        List<String> lines = new ArrayList<>();
        Process p = Runtime.getRuntime().exec(
                new String[]{
                    "bash", "-c", cmd + " cols 2> /dev/tty"
                }
        );
        //Process p = Runtime.getRuntime().exec(cmd);
        p.waitFor();
        BufferedReader in = new BufferedReader(
                new InputStreamReader(p.getInputStream())
        );
        String line = "";
        while ((line = in.readLine()) != null) {
            lines.add(line);
        }
        return lines;
    }

    private void printImage(int imgIndex) {
        //byte[] data = Files.readAllBytes(imgPaths.get(imgIndex));
        BitmapModel bmp = images.get(imgIndex);//new BitmapModel(data);
        int w = Math.min(width, bmp.getWidth());
        int h = Math.min(height, bmp.getHeight());
        //System.out.printf("w:%d h:%d \n", bmp.getWidth(), bmp.getHeight());
        int dx = (width - w) / 2;
        int dy = (height - h) / 2;
        //System.out.printf("w:%d h:%d dx:%d dy:%d\n", w, h, dx, dy);
        int[] black = {0, 0, 0};
        StringBuilder out = new StringBuilder(width + 1 * height);
        for (int i = 0; i < dy; i++) {
            for (int j = 0; j < width; j++) {
                out.append(
                        bmp.getColoredString(
                                0,
                                "X"
                        )
                );
            }
            out.append(System.lineSeparator());
        }
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < dx; j++) {
                out.append(
                        bmp.getColoredString(
                                0,
                                "X"
                        )
                );
            }
            for (int j = 0; j < w; j++) {
                int[] pixelData = bmp.getPixelData(j, i);
                int color = ColorConverter.getNearestAnsi16(pixelData);
                out.append(
                        bmp.getColoredString(
                                color,
                                "X"
                        )
                );
            }
            for (int j = 0; j < dx; j++) {
                out.append(
                        bmp.getColoredString(
                                0,
                                " "
                        )
                );
            }
            out.append(System.lineSeparator());
        }
        for (int i = 0; i < dy; i++) {
            for (int j = 0; j < width; j++) {
                out.append(
                        bmp.getColoredString(
                                0,
                                "X"
                        )
                );
            }
            out.append(System.lineSeparator());
        }
        System.out.print(out.toString());
        System.out.flush();
    }
}
