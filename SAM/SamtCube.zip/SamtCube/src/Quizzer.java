
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Classe Quizzer
 *
 * @author Michele Tomyslak
 * @author Andrea Rauso
 * @version 26.02.2018
 *
 */
public class Quizzer {

    private Path csvPath;
    private int questionsPerQuiz;
    private char separator;
    private List<QuizQuestion> questions;

    /**
     * metodo getCsvPath che ritorna la path del file
     *
     * @return la path del file
     */
    public Path getCsvPath() {
        return this.csvPath;
    }

    /**
     * metodo getQuestions che ritorna il numero di domande da fare
     *
     * @return il numero di domande
     */
    public int getQuestionsPerQuiz() {
        return this.questionsPerQuiz;
    }

    /**
     * Metodo costruttore con 3 attributi
     *
     * @param csvPath la path del file
     * @param questions il numero di domande
     * @param separator il carattere di separazione
     */
    public Quizzer(String csvPath, int questions, char separator) throws IOException {
        Path file = Paths.get(csvPath);
        this.csvPath = Paths.get(csvPath).toAbsolutePath();
        this.questionsPerQuiz = questions;
        this.separator = separator;
        this.questions = new ArrayList<>();
        loadQuestions();
    }

    public void loadQuestions() throws IOException {
        List<String> lines = Files.readAllLines(csvPath);
        if (lines.size() < questionsPerQuiz) {
            throw new IOException("Il file delle domande non contiene dati sufficienti.");
        } else {
            for (String line : lines) {
                String[] parts = line.split(separator + "");
                if (parts.length < 3) {
                    throw new IOException("Formato file domande errato.");
                } else {
                    this.questions.add(
                            new QuizQuestion(
                                    parts[0],
                                    parts[1],
                                    Arrays.copyOfRange(parts, 2, parts.length)
                            )
                    );
                }
            }
        }
    }

    /**
     * metodo getRandomQuestion per ottenere domande casuali
     *
     * @return un array di domande
     */
    public QuizQuestion[] getRandomQuestions() {
        QuizQuestion[] randomQuestions = new QuizQuestion[this.questionsPerQuiz];
        List<QuizQuestion> dumQuestions = new ArrayList<>();
        for (QuizQuestion question : questions) {
            dumQuestions.add(question);
        }
        int rnd = (int) (Math.random() * dumQuestions.size());
        randomQuestions[0] = dumQuestions.remove(rnd);
        rnd = (int) (Math.random() * dumQuestions.size());
        randomQuestions[1] = dumQuestions.remove(rnd);
        rnd = (int) (Math.random() * dumQuestions.size());
        randomQuestions[2] = dumQuestions.remove(rnd);
        //       List<Integer> indexes = new ArrayList<>();
//        for (int i = 0; i < this.questionsPerQuiz; i++) {
//            int rnd = (int) (Math.random() * this.questions.size());
//            randomQuestions[i] = questions.remove(rnd);
//        }
        return randomQuestions;
    }
}
