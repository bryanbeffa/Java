
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * The MIT License
 *
 * Copyright 2018 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/**
 *
 * @author andreaalbertini
 */
public class SamtQuiz {

    public static final String QUIT_COMMAND = "quit";

    public static final String CSV_FILE_NAME = "data.csv";
    public static final String CSV_PATH = "quizdata";

    public static final int TERM_COLS = 109;//82;
    public static final int TERM_ROWS = 34;//26;
    public static final char DATA_CSV_SEPARATOR = ',';

    public static final String QUESTIONS_PATH = "questions.csv";
    public static final int QUESTIONS_PER_QUIZ = 3;
    public static final char QUIZ_CSV_SEPARATOR = ';';

    private static final String IMAGES_PATH = "img";
    private final Asker asker;
    private final CsvSaver saver;
    private final ScreenManager screen;
    private final Quizzer quizzer;

    private String getHostname() {
        String hostname = "unknown";
        try {
            List<String> lines = new ArrayList<>();
            Process p = Runtime.getRuntime().exec("hostname");
            p.waitFor();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(p.getInputStream())
            );
            String line = "";
            while ((line = in.readLine()) != null) {
                lines.add(line);
            }
            if (lines.size() > 0) {
                hostname = lines.get(0);
            }
        } catch (InterruptedException | IOException ex) {
        }
        return hostname;
    }

    public SamtQuiz() throws IOException {
        asker = new Asker(QUIT_COMMAND);
        screen = new ScreenManager(IMAGES_PATH, TERM_COLS, TERM_ROWS);

        saver = new CsvSaver(
                getHostname(),
                CSV_PATH,
                CSV_FILE_NAME,
                DATA_CSV_SEPARATOR
        );

        quizzer = new Quizzer(
                QUESTIONS_PATH,
                QUESTIONS_PER_QUIZ,
                QUIZ_CSV_SEPARATOR
        );
    }

    public void mainLoop() throws IOException {
        //stampa spash screen e attendi tasto
        screen.setGraphicFont();
        screen.showSplash();
        //inizia form e quiz
        screen.setBigFont();
        screen.clearScreen();
        FormRecord record = new FormRecord();
        try {
            //verifica partecipante frequenta se SM
            screen.clearScreen();
            System.out.println(
                    getColoredString(9,
                            "Al concorso possono partecipare solo gli alunni di SM."
                    )
            );
            System.out.println("");
            System.out.println("Confermi di frequentare attualemente la Scuola Media?");
            System.out.println("1. Si");
            System.out.println("2. No");
            System.out.println("Digitare 1 per Si, 2 per No");
            String isSM = asker.ask("La tua risposta ", new IntegerValidator(1, 2));
            if (isSM.equals("2")) {
                throw new FormInterruptedException("Form interrotto, il partecipante non frequenta la SM.");
            }
            screen.clearScreen();
            System.out.println("Ti verranno proposti un breve formulario e un quiz");
            System.out.println();
            System.out.println("Puoi interrompere la partecipazione digitando \"quit\"");
            Thread.sleep(5000);
            screen.clearScreen();
            //compila form
            runForm(record);
            screen.clearScreen();
            confirmFormData(record);
            //quiz
            screen.clearScreen();
            FormField pontsField = record.getFields().get("Punti");
            pontsField.setValue(runQuiz() + "");

            //salva
            saver.save(record);
            System.out.println("Grazie per aver partecipato.");
            System.out.println("Sarai contattato dopo l'estrazione.");
            Thread.sleep(2000);
        } catch (FormInterruptedException fie) {
            System.out.println("Compilazione interrotta dall'utente");
        } catch (InterruptedException ex) {
            return;
        }

    }

    private void confirmFormData(FormRecord record) throws IOException, FormInterruptedException, NumberFormatException {
        //chiedi conferma e ev. correggi dati
        boolean done = false;
        do {
            screen.clearScreen();
            System.out.println("I tuoi dati:");
            System.out.println("");
            showFormData(record);
            System.out.println("");
            System.out.println("Tutti i dati sono corretti?");
            System.out.println("1. Si");
            System.out.println("2. No");
            System.out.println("Digitare 1 per Si, 2 per No");
            System.out.println();
            if (asker.ask("La tua risposta", new IntegerValidator(1, 2)).equals("2")) {
                screen.clearScreen();
                System.out.println("Quale dato vuoi modificare?");
                showFormDataWithId(record);
                int modId = Integer.parseInt(
                        asker.ask(
                                "La tua risposta",
                                new IntegerValidator(1, record.getFields().size() - 1
                                )
                        )
                );
                FormField field = (FormField) record.getFields().values().toArray()[modId - 1];
                field.setValue(asker.ask(field.getName(), field.getValidator()));
            } else {
                done = true;
            }
        } while (!done);
    }

    private void showFormDataWithId(FormRecord record) throws IOException, FormInterruptedException, NumberFormatException {
        Map<String, FormField> fields = record.getFields();
        int id = 1;
        for (Map.Entry<String, FormField> entry : fields.entrySet()) {
            String key = entry.getKey();
            FormField field = entry.getValue();
            if (!key.equalsIgnoreCase("punti")) {
                System.out.printf("%d. %s: %s\n",
                        id++,
                        getColoredString(9, field.getName()),
                        getColoredString(2, field.getValue())
                );
            }
        }
    }

    private void showFormData(FormRecord record) throws IOException, FormInterruptedException, NumberFormatException {
        Map<String, FormField> fields = record.getFields();
        for (Map.Entry<String, FormField> entry : fields.entrySet()) {
            String key = entry.getKey();
            FormField field = entry.getValue();
            if (!key.equalsIgnoreCase("punti")) {
                System.out.printf("%s: %s\n",
                        getColoredString(9, field.getName()),
                        getColoredString(2, field.getValue())
                );
            }
        }
    }

    private void runForm(FormRecord record) throws IOException, FormInterruptedException, NumberFormatException {
        Map<String, FormField> fields = record.getFields();
        for (Map.Entry<String, FormField> entry : fields.entrySet()) {
            String key = entry.getKey();
            FormField field = entry.getValue();
            screen.clearScreen();
            if (!key.equalsIgnoreCase("punti")) {
                String request = field.getName();
                if (field.getExplaination().trim().length() != 0) {
                    request = "Inserire " + field.getName() + System.lineSeparator();
                    request += field.getExplaination() + System.lineSeparator() + System.lineSeparator();
                    request += field.getName();
                }
                field.setValue(asker.ask(request, field.getValidator()));
            }
        }
    }

    private int runQuiz() throws FormInterruptedException, NumberFormatException, IOException {
        int points = 0;
        QuizQuestion[] questions = quizzer.getRandomQuestions();
        for (int i = 0; i < questions.length; i++) {
            System.out.println(getColoredString(9, questions[i].getQuestionText()));
            System.out.println("");
            String[] answers = questions[i].getAnswers();
            for (int j = 0; j < answers.length; j++) {
                System.out.println(getColoredString(2, (j + 1) + ". " + answers[j]));
                System.out.println("");
            }
            int reply = Integer.parseInt(
                    asker.ask("La tua risposta",
                            new IntegerValidator(1, 3))
            );
            if (reply - 1 == questions[i].getCorrectAnswer()) {
                points++;
            }
            screen.clearScreen();
        }
        return points;
    }

    private String getColoredString(int code, String text) {
        return "\033[38;5;" + code + "m" + text + "\033[0;00m";
    }

    private String getColoredBgString(int code, String text) {
        return "\033[48;5;" + code + "m" + text + "\033[0;00m";
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        SamtQuiz quiz = new SamtQuiz();
        while (true) {
            quiz.mainLoop();
        }
    }

}
