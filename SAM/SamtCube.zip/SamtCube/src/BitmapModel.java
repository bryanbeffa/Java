

/*
 * The MIT License
 *
 * Copyright 2017 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/**
 * Vedi: https://en.wikipedia.org/wiki/BMP_file_format
 * Vedi: http://web.archive.org/web/20131009193526/http://bitmote.com/index.php?post/2012/11/19/Using-ANSI-Color-Codes-to-Colorize-Your-Bash-Prompt-on-Linux
 *
 * @author andreaalbertini
 */
public class BitmapModel {

    public static final char[] DEFAULT_CHARS = {'X', 'Y', '#', 'ä', 'ö', 'ü', '?', 'o', '*', 'i', '=', '+', ':', '°', '.', ' '};
    private char[] chars = DEFAULT_CHARS;
    private byte[] data;

    public void setChars(String chars) {
        this.chars = chars.toCharArray();
    }

    private int getInt(int offset, int len) {
        int value = 0;
        if (offset + len < data.length) {
            for (int i = offset; i < offset + len; i++) {
                value += (data[i] & 0xFF) << ((i - offset) * 8);
            }
        }
        return value;
    }

    public String getSignature() {
        return "" + (char) data[0] + (char) data[1];
    }

    public int getFileSize() {
        return getInt(2, 4);
    }

    public int getReserved1() {
        return getInt(6, 2);
    }

    public int getReserved2() {
        return getInt(8, 2);
    }

    public int getFileOffset() {
        return getInt(10, 4);
    }

    public int getDibHeaderSize() {
        return getInt(14, 4);
    }

    public int getWidth() {
        return getInt(18, 4);
    }

    public int getHeight() {
        return getInt(22, 4);
    }

    public int getColorPlanesNumber() {
        return getInt(26, 2);
    }

    public int getBitsPerPixel() {
        return getInt(28, 2);
    }

    public int getCompressionMethod() {
        return getInt(30, 4);
    }

    /*
	0	BI_RGB	none	Most common
	1	BI_RLE8	RLE 8-bit/pixel	Can be used only with 8-bit/pixel bitmaps
	2	BI_RLE4	RLE 4-bit/pixel	Can be used only with 4-bit/pixel bitmaps
	3	BI_BITFIELDS	OS22XBITMAPHEADER: Huffman 1D	BITMAPV2INFOHEADER: RGB bit field masks, BITMAPV3INFOHEADER+: RGBA
	4	BI_JPEG	OS22XBITMAPHEADER: RLE-24	BITMAPV4INFOHEADER+: JPEG image for printing[12]
	5	BI_PNG		BITMAPV4INFOHEADER+: PNG image for printing[12]
	6	BI_ALPHABITFIELDS	RGBA bit field masks	only Windows CE 5.0 with .NET 4.0 or later
	11	BI_CMYK	none	only Windows Metafile CMYK[3]
	12	BI_CMYKRLE8	RLE-8	only Windows Metafile CMYK
	13	BI_CMYKRLE4	RLE-4	only Windows Metafile CMYK
     */
    public String getCompressionMethodName(int code) {
        switch (code) {
            case 0:
                return "BI_RGB (none)";
            case 1:
                return "BI_RLE8";
            case 2:
                return "BI_RLE4";
            case 3:
                return "BI_BITFIELDS";
            case 4:
                return "BI_JPEG";
            case 5:
                return "BI_PNG";
            case 6:
                return "BI_ALPHABITFIELDS";
            case 11:
                return "BI_CMYK";
            case 12:
                return "BI_CMYKRLE8";
            case 13:
                return "BI_CMYKRLE4";
            default:
                return "WRONG COMPRESSION CODE";
        }
    }

    public int getImageSize() {
        return getInt(34, 4);
    }

    public int getResolutionH() {
        return getInt(38, 4);
    }

    public int getResolutionV() {
        return getInt(42, 4);
    }

    public int getColorsNumber() {
        return getInt(46, 4);
    }

    public int getImportantColorsNumber() {
        return getInt(50, 4);
    }

    public byte[] getImageData() {
        byte[] imageData = new byte[(int) getImageSize()];
        int offset = getFileOffset();
        int size = getImageSize();
        for (int i = offset; i < offset + size; i++) {
            imageData[i - offset] = data[i];
        }
        return imageData;
    }

    public int getRowSize() {
        return 4 * ((int) (getBitsPerPixel() * getWidth() + 31) / 32);
    }

    public int getPixelOffset(int x, int y) {
        int row = getHeight() - y - 1;
        int col = x;
        //int padding = getRowSize() - getWidth();
        return row * getRowSize() + col * 3;
    }

    public int[] getPixelData(int x, int y) {
        int[] pixelData = new int[getBitsPerPixel() / 8];
        int offset = getFileOffset() + getPixelOffset(x, y);
        for (int i = 0; i < pixelData.length; i++) {
            pixelData[i] = data[offset + i] & 0xFF;
        }
        return pixelData;
    }

    public String getGrayScalePixel(int[] pixelData) {
        int code = getGrayScaleCode(pixelData);
        return "\033[48;5;" + code + "m  \033[0;00m";
    }

    public int getGrayScaleCode(int[] pixelData) {
        int sum = pixelData[0] + pixelData[1] + pixelData[2];
        int code = 232 + (int) (sum * 24.0 / 765.0);
        return code;
    }
    //round(36 * (r * 5) + 6 * (g * 5) + (b * 5) + 16)

    public String getColorPixel(int[] pixelData) {
    int code = getColorCode(pixelData);
        return getColoredBgString(code, "  ");
    }

    public String getColoredString(int code, String text) {
        return "\033[38;5;" + code + "m" + text + "\033[0;00m";
    }

    public String getColoredBgString(int code, String text) {
        return "\033[48;5;" + code + "m" + text + "\033[0;00m";
    }

    public String getAsciiPixel(int[] pixelData) {
        int sum = (pixelData[0] + pixelData[1] + pixelData[2]);
        int code = (int) (sum * (chars.length - 1) / 765.0);
        return (char) chars[code] + "";// + (char) (chars[code]);
    }

    public int getColorCode(int[] pixelData) {
        //int sum = pixelData[0]+pixelData[1]+pixelData[2];
        int r = 5 * pixelData[2] / 255;
        int g = 5 * pixelData[1] / 255;
        int b = 5 * pixelData[0] / 255;
        int row = 16 + r * 36;
        int col = 6 * g + b;
        int code = row + col;
        return code;
    }

    public void drawImage() {
        for (int i = 0; i < getHeight(); i++) {
            for (int j = 0; j < getWidth(); j++) {
                int[] pixelData = getPixelData(j, i);
                //System.out.printf("%02x%02x%02x ",pixelData[0],pixelData[1],pixelData[2]);
                //System.out.print(getAsciiPixel(pixelData));
                System.out.print(
                        getColoredBgString(
                                getColorCode(pixelData),
                                getAsciiPixel(pixelData)
                        )
                );
            }
            System.out.println(getColoredBgString(
                    getColorCode(new int[]{0xff, 0xff, 0xff}),
                    " "
            ));
        }
    }

    public void dumpHeader() {
        System.out.println("Signature: " + getSignature());
        System.out.println("Size: " + getFileSize());
        System.out.println("Reserved1: " + getReserved1());
        System.out.println("Reserved2: " + getReserved2());
        System.out.println("Offset: " + getFileOffset());
        System.out.println("DIB header size: " + getDibHeaderSize());
        System.out.println("Width: " + getWidth());
        System.out.println("Height: " + getHeight());
        System.out.println("Color planes: " + getColorPlanesNumber());
        System.out.println("Bits per pixel: " + getBitsPerPixel());
        System.out.println("Compression method: " + getCompressionMethodName(getCompressionMethod()));
        System.out.println("Image size: " + getImageSize());
        System.out.println("Horizontal resolution (px/m): " + getResolutionH());
        System.out.println("Vertical resolution (px/m): " + getResolutionV());
        System.out.println("Number of colors: " + getColorsNumber());
        System.out.println("Number of important colors: " + getImportantColorsNumber());
        System.out.println("Row size: " + getRowSize());
    }

    public void dumpImage() {
        for (int i = getHeight() - 1; i >= 0; i--) {
            System.out.printf("%04x\t", i * getWidth());
            for (int j = 0; j < getWidth(); j++) {
                int[] pixelData = getPixelData(j, i);
                int[] negData = new int[pixelData.length];
                for (int k = 0; k < negData.length; k++) {
                    negData[k] = 255 - pixelData[k];
                }

                String pixel = String.format("%02x%02x%02x", pixelData[0], pixelData[1], pixelData[2]);
                System.out.print(
                        getColoredBgString(
                                getColorCode(pixelData),
                                getColoredString(getColorCode(negData), pixel)
                        )
                );
            }
            System.out.println();
        }
    }

    public void dumpImageData() {
        byte[] imageData = getImageData();
        for (int i = 0; i < getHeight(); i++) {
            System.out.printf("%04x\t", i * getWidth());
            int j = 0;
            while (j < getRowSize()) {
                int offset = i * getRowSize() + j;
                int value = imageData[offset];
                if (offset >= getWidth()) {//padding
                    System.out.printf("%02x ", value);
                    j++;
                } else {
                    //System.out.println("\n"+i+" "+j+" "+getRowSize());
                    int[] pixelData = getPixelData(j, i);
                    int[] negData = new int[pixelData.length];
                    for (int k = 0; k < negData.length; k++) {
                        negData[k] = 255 - pixelData[k];
                    }

                    String pixel = String.format("%02x%02x%02x ", pixelData[0], pixelData[1], pixelData[2]);
                    System.out.print(
                            getColoredBgString(
                                    getColorCode(pixelData),
                                    getColoredString(getColorCode(negData), pixel)
                            )
                    );
                    j += 3;
                }

            }
            System.out.println();
        }
    }

    public BitmapModel(byte[] data) {
        this.data = data;
    }
}
