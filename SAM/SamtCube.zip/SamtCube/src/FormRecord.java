
import java.util.LinkedHashMap;
import java.util.Map;

/*
 * The MIT License
 *
 * Copyright 2018 andreaalbertini.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/**
 *
 * @author andreaalbertini
 */
public class FormRecord {

    protected Map<String, FormField> fields;

    public FormRecord() {
        fields = new LinkedHashMap<>();
        addField(new FormField("Nome", new NameValidator(20)));
        addField(new FormField("Cognome", new NameValidator(20)));
        //addField(new FormField("Email", new EmailValidator()));
        addField(
                new FormField(
                        "Anno di nascita",
                        new IntegerValidator(1998, 2007),
                        "Inserire il proprio anno di nascita in cifre (es. 2005)"
                )
        );
        addField(new FormField("Nome genitore", new NameValidator(20)));
        addField(new FormField("Cognome genitore", new NameValidator(20)));
        addField(
                new FormField(
                        "Email genitore",
                        new EmailValidator(),
                        "Premi i tasti [Alt Gr] e [2] per ottenere \'@\'"
                )
        );
        addField(
                new FormField(
                        "Sede di Scuola Media frequentata", 
                        new NameValidator(20),
                        "Digita la sede di SM che frequenti (es. Canobbio o Massagno)"
                )
        );
        addField(
                new FormField(
                        "Classe frequentata", 
                        new IntegerValidator(1, 4),
                        "Digita la classe di SM che frequenti (1, 2, 3 o 4)"
                )
        );
        addField(new FormField("Punti", new IntegerValidator(1, 6)));
    }

    private void addField(FormField field) {
        this.fields.put(field.getName(), field);
    }

    public Map<String, FormField> getFields() {
        return fields;
    }

}
