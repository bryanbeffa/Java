#!/bin/bash
echo 'cubeA'
scp dist/*.jar pi@samtcubea.local:/home/pi/
scp questions.csv pi@samtcubea.local:/home/pi/questions.csv
scp profile pi@samtcubea.local:/home/pi/profile.dist
scp go.sh pi@samtcubea.local:/home/pi/go.dist
scp img/*.bmp pi@samtcubea.local:/home/pi/img
scp font/*.psf pi@samtcubea.local:/home/pi
echo 'cubeB'
scp dist/*.jar pi@samtcubeb.local:/home/pi/
scp questions.csv pi@samtcubeb.local:/home/pi/questions.csv
scp profile pi@samtcubeb.local:/home/pi/profile.dist
scp go.sh pi@samtcubeb.local:/home/pi/go.dist
scp img/*.bmp pi@samtcubeb.local:/home/pi/img
scp font/*.psf pi@samtcubeb.local:/home/pi
#echo 'cubeC'
#scp dist/*.jar pi@samtcubec.local:/home/pi/
#scp questions.csv pi@samtcubec.local:/home/pi/questions.csv
#scp profile pi@samtcubec.local:/home/pi/profile.dist
#scp go.sh pi@samtcubec.local:/home/pi/go.dist
#scp img/*.bmp pi@samtcubec.local:/home/pi/img
#scp font/*.psf pi@samtcubec.local:/home/pi
#echo 'cubeD'
#scp dist/*.jar pi@samtcubed.local:/home/pi/
#scp questions.csv pi@samtcubed.local:/home/pi/questions.csv
#scp profile pi@samtcubed.local:/home/pi/profile.dist
#scp go.sh pi@samtcubed.local:/home/pi/go.dist
#scp img/*.bmp pi@samtcubed.local:/home/pi/img
#scp font/*.psf pi@samtcubed.local:/home/pi
