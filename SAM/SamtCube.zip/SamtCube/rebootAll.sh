#!/bin/bash
ssh pi@samtcubea.local 'sudo reboot'
ssh pi@samtcubeb.local 'sudo reboot'
ssh pi@samtcubec.local 'sudo reboot'
ssh pi@samtcubed.local 'sudo reboot'

