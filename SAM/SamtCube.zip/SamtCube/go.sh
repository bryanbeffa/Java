#!/bin/bash
cd /home/pi
java -jar SamtCube.jar
setfont Uni3-Terminus12x6

