#!/bin/bash
ssh pi@samtcubeA.local sudo shutdown -h now
ssh pi@samtcubeB.local sudo shutdown -h now
ssh pi@samtcubeC.local sudo shutdown -h now
ssh pi@samtcubeD.local sudo shutdown -h now

